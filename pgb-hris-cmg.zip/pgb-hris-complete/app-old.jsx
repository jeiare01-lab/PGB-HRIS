import React, { useState } from 'react';

export default function HRISDashboard() {
  const [activeTab, setActiveTab] = useState(0);
  const [selectedCompany, setSelectedCompany] = useState(null);

  const tabs = ['📊 Executive', '🛠️ HR Operations', '🤝 HR Service Delivery', '🎓 HR COE', '🏥 HR OHSW', '🚀 Strategic HR'];

  const companies = {
    PSC: { name: 'PSC Construction', headcount: 95, performers: 27, ttf: 32, costPerHire: '₱34K', rock1: '-9%', rock2: '88%', rock3: '+6%', rock4: '94%' },
    ABC: { name: 'ABC Manufacturing', headcount: 52, performers: 15, ttf: 36, costPerHire: '₱36K', rock1: '-7%', rock2: '82%', rock3: '+4%', rock4: '90%' },
    CSI: { name: 'CSI Manufacturing', headcount: 33, performers: 8, ttf: 38, costPerHire: '₱35K', rock1: '-8%', rock2: '80%', rock3: '+3%', rock4: '92%' },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-slate-900 to-black p-6">
      <div className="max-w-7xl mx-auto">
        {/* HEADER */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white rounded-3xl p-8 mb-8 shadow-2xl">
          <h1 className="text-5xl font-black mb-2">SBU: Construction & Manufacturing Group</h1>
          <p className="text-2xl font-bold text-white/90 mb-2">(CMG)</p>
          <p className="text-lg mb-4">PSC • ABC • CSI</p>
          <p className="text-sm text-white/70">Click on a Business Affiliate below to see company breakdown →</p>
        </div>

        {/* BUSINESS AFFILIATES SELECTOR */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {['PSC', 'ABC', 'CSI'].map((code) => (
            <button
              key={code}
              onClick={() => setSelectedCompany(code)}
              className={`p-4 rounded-2xl font-black text-lg transition transform hover:scale-105 ${
                selectedCompany === code
                  ? 'bg-gradient-to-br from-cyan-400 to-blue-600 text-white shadow-2xl scale-105'
                  : 'bg-white/10 text-white shadow-lg hover:bg-white/20'
              }`}
            >
              {code}
              <p className="text-xs text-white/80 mt-1">{companies[code].name}</p>
            </button>
          ))}
        </div>

        {/* COMPANY BREAKDOWN MODAL */}
        {selectedCompany && (
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-8 mb-8 border-2 border-cyan-400 shadow-2xl">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-4xl font-black text-white mb-2">{companies[selectedCompany].name}</h2>
                <p className="text-cyan-300 font-bold">Company Breakdown</p>
              </div>
              <button
                onClick={() => setSelectedCompany(null)}
                className="px-4 py-2 bg-red-600 text-white rounded-lg font-bold hover:bg-red-700"
              >
                ✕ Close
              </button>
            </div>

            {/* COMPANY ROCKS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <div className="bg-gradient-to-br from-emerald-400 to-green-600 text-white rounded-2xl p-6 shadow-xl">
                <p className="text-white/80 font-semibold text-sm">Rock 1: Cash Position</p>
                <p className="text-4xl font-black mt-2">{companies[selectedCompany].rock1}</p>
              </div>
              <div className="bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-2xl p-6 shadow-xl">
                <p className="text-white/80 font-semibold text-sm">Rock 2: Succession</p>
                <p className="text-4xl font-black mt-2">{companies[selectedCompany].rock2}</p>
              </div>
              <div className="bg-gradient-to-br from-purple-400 to-purple-600 text-white rounded-2xl p-6 shadow-xl">
                <p className="text-white/80 font-semibold text-sm">Rock 3: Productivity</p>
                <p className="text-4xl font-black mt-2">{companies[selectedCompany].rock3}</p>
              </div>
              <div className="bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-2xl p-6 shadow-xl">
                <p className="text-white/80 font-semibold text-sm">Rock 4: Partnership</p>
                <p className="text-4xl font-black mt-2">{companies[selectedCompany].rock4}</p>
              </div>
            </div>

            {/* COMPANY KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl p-4 shadow-lg">
                <p className="text-white/80 text-xs font-medium">Headcount</p>
                <p className="text-3xl font-black mt-2">{companies[selectedCompany].headcount}</p>
              </div>
              <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-xl p-4 shadow-lg">
                <p className="text-white/80 text-xs font-medium">High Performers</p>
                <p className="text-3xl font-black mt-2">{companies[selectedCompany].performers}</p>
              </div>
              <div className="bg-gradient-to-br from-yellow-500 to-orange-600 text-white rounded-xl p-4 shadow-lg">
                <p className="text-white/80 text-xs font-medium">Time-to-Fill</p>
                <p className="text-3xl font-black mt-2">{companies[selectedCompany].ttf}d</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-xl p-4 shadow-lg">
                <p className="text-white/80 text-xs font-medium">Cost-per-Hire</p>
                <p className="text-2xl font-black mt-2">{companies[selectedCompany].costPerHire}</p>
              </div>
            </div>
          </div>
        )}

        {/* TABS */}
        <div className="flex gap-2 overflow-x-auto mb-8 pb-4">
          {tabs.map((tab, i) => (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              className={`px-6 py-3 rounded-xl font-bold whitespace-nowrap transition transform ${
                activeTab === i
                  ? 'bg-blue-600 text-white shadow-lg scale-105'
                  : 'bg-white text-gray-700 shadow-md hover:shadow-lg'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* EXECUTIVE DASHBOARD */}
        {activeTab === 0 && (
          <div className="space-y-8">
            {/* ROCKS */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-emerald-400 to-green-600 text-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition transform hover:scale-105">
                <div className="text-5xl mb-3">💰</div>
                <p className="text-white/80 font-semibold">ROCK 1</p>
                <h3 className="text-2xl font-black mt-2">Cash Position</h3>
                <p className="text-4xl font-black mt-3">-8%</p>
                <p className="text-white/70 text-sm mt-1">Cost-per-Hire Savings</p>
              </div>

              <div className="bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition transform hover:scale-105">
                <div className="text-5xl mb-3">👥</div>
                <p className="text-white/80 font-semibold">ROCK 2</p>
                <h3 className="text-2xl font-black mt-2">Succession</h3>
                <p className="text-4xl font-black mt-3">85%</p>
                <p className="text-white/70 text-sm mt-1">Coverage Target</p>
              </div>

              <div className="bg-gradient-to-br from-purple-400 to-purple-600 text-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition transform hover:scale-105">
                <div className="text-5xl mb-3">📈</div>
                <p className="text-white/80 font-semibold">ROCK 3</p>
                <h3 className="text-2xl font-black mt-2">Productivity</h3>
                <p className="text-4xl font-black mt-3">+5%</p>
                <p className="text-white/70 text-sm mt-1">FTE Output Gain</p>
              </div>

              <div className="bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition transform hover:scale-105">
                <div className="text-5xl mb-3">🤝</div>
                <p className="text-white/80 font-semibold">ROCK 4</p>
                <h3 className="text-2xl font-black mt-2">Partnership</h3>
                <p className="text-4xl font-black mt-3">92%</p>
                <p className="text-white/70 text-sm mt-1">Mgmt Readiness</p>
              </div>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Active Headcount</p>
                <p className="text-5xl font-black mt-3">180</p>
                <p className="text-white/70 text-xs mt-1">Employees</p>
              </div>

              <div className="bg-gradient-to-br from-green-500 to-emerald-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">High Performers</p>
                <p className="text-5xl font-black mt-3">50</p>
                <p className="text-white/70 text-xs mt-1">Rating 4-5</p>
              </div>

              <div className="bg-gradient-to-br from-yellow-500 to-orange-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Time-to-Fill</p>
                <p className="text-5xl font-black mt-3">35</p>
                <p className="text-white/70 text-xs mt-1">Days Avg</p>
              </div>

              <div className="bg-gradient-to-br from-purple-500 to-pink-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Cost-per-Hire</p>
                <p className="text-4xl font-black mt-3">₱35K</p>
                <p className="text-white/70 text-xs mt-1">CMG Average</p>
              </div>
            </div>

            {/* SUMMARY */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-green-100 to-emerald-200 rounded-2xl p-8 border-3 border-green-300 shadow-lg hover:shadow-xl transition">
                <h3 className="text-2xl font-black text-green-900 mb-4">✓ Highlights</h3>
                <ul className="space-y-2 text-green-800 font-semibold">
                  <li>✓ 180 active headcount</li>
                  <li>✓ 28% high performer rate</li>
                  <li>✓ 85% succession coverage</li>
                  <li>✓ 35-day time-to-fill</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-yellow-100 to-orange-200 rounded-2xl p-8 border-3 border-yellow-300 shadow-lg hover:shadow-xl transition">
                <h3 className="text-2xl font-black text-yellow-900 mb-4">⚠️ Areas to Watch</h3>
                <ul className="space-y-2 text-yellow-800 font-semibold">
                  <li>• 3 critical positions open</li>
                  <li>• Training compliance 88%</li>
                  <li>• 2 employees on PIP</li>
                  <li>• 1 incident in July</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-blue-100 to-cyan-200 rounded-2xl p-8 border-3 border-blue-300 shadow-lg hover:shadow-xl transition">
                <h3 className="text-2xl font-black text-blue-900 mb-4">⏰ Next 90 Days</h3>
                <ul className="space-y-2 text-blue-800 font-semibold">
                  <li>1. Finalize Succession</li>
                  <li>2. Talent Calibration</li>
                  <li>3. Dev Plan Launch</li>
                  <li>4. Q4 Reviews</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* HR OPERATIONS */}
        {activeTab === 1 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-blue-400 to-blue-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Payroll Accuracy</p>
                <p className="text-5xl font-black mt-3">99.8%</p>
                <p className="text-white/70 text-xs mt-1">Error-free processing</p>
              </div>
              <div className="bg-gradient-to-br from-purple-400 to-purple-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Records Management</p>
                <p className="text-5xl font-black mt-3">100%</p>
                <p className="text-white/70 text-xs mt-1">Compliant & updated</p>
              </div>
              <div className="bg-gradient-to-br from-indigo-400 to-indigo-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Leave Processing</p>
                <p className="text-5xl font-black mt-3">98%</p>
                <p className="text-white/70 text-xs mt-1">Timely approval</p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl p-8 border-3 border-blue-400 shadow-lg">
              <h2 className="text-4xl font-black text-blue-900 mb-6">HR Operations Dashboard</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-4xl font-black text-blue-700">240</p>
                  <p className="text-blue-800 font-bold mt-2">Payroll Cycles</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-purple-700">98%</p>
                  <p className="text-purple-800 font-bold mt-2">On-time</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-indigo-700">180</p>
                  <p className="text-indigo-800 font-bold mt-2">Files Maintained</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-cyan-700">15</p>
                  <p className="text-cyan-800 font-bold mt-2">Days Avg Response</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* HR SERVICE DELIVERY */}
        {activeTab === 2 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-green-400 to-green-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Employee Satisfaction</p>
                <p className="text-5xl font-black mt-3">4.5/5</p>
                <p className="text-white/70 text-xs mt-1">Average rating</p>
              </div>
              <div className="bg-gradient-to-br from-emerald-400 to-emerald-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Ticket Resolution</p>
                <p className="text-5xl font-black mt-3">94%</p>
                <p className="text-white/70 text-xs mt-1">First contact</p>
              </div>
              <div className="bg-gradient-to-br from-teal-400 to-teal-600 text-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                <p className="text-white/80 text-sm font-medium">Response Time</p>
                <p className="text-5xl font-black mt-3">2.5h</p>
                <p className="text-white/70 text-xs mt-1">Average</p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-green-100 to-emerald-200 rounded-2xl p-8 border-3 border-green-400 shadow-lg">
              <h2 className="text-4xl font-black text-green-900 mb-6">Service Delivery Metrics</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-4xl font-black text-green-700">1,850</p>
                  <p className="text-green-800 font-bold mt-2">Requests Handled</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-emerald-700">87%</p>
                  <p className="text-emerald-800 font-bold mt-2">On-time Delivery</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-teal-700">98%</p>
                  <p className="text-teal-800 font-bold mt-2">Accuracy</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-cyan-700">12</p>
                  <p className="text-cyan-800 font-bold mt-2">Services Offered</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* OHSW */}
        {activeTab === 3 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-red-100 to-red-200 rounded-2xl p-8 border-3 border-red-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-red-700 font-bold text-lg">Safety Training</p>
                <p className="text-5xl font-black text-red-900 mt-2">92%</p>
              </div>
              <div className="bg-gradient-to-br from-orange-100 to-orange-200 rounded-2xl p-8 border-3 border-orange-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-orange-700 font-bold text-lg">Incident Rate</p>
                <p className="text-5xl font-black text-orange-900 mt-2">1.2</p>
              </div>
              <div className="bg-gradient-to-br from-green-100 to-emerald-200 rounded-2xl p-8 border-3 border-green-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-green-700 font-bold text-lg">Wellness Program</p>
                <p className="text-5xl font-black text-green-900 mt-2">68%</p>
              </div>
              <div className="bg-gradient-to-br from-blue-100 to-cyan-200 rounded-2xl p-8 border-3 border-blue-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-blue-700 font-bold text-lg">Cost Avoidance</p>
                <p className="text-4xl font-black text-blue-900 mt-2">₱2.7M</p>
              </div>
            </div>
          </div>
        )}

        {/* HR CENTER OF EXCELLENCE */}
        {activeTab === 4 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-amber-100 to-yellow-200 rounded-2xl p-8 border-3 border-amber-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-amber-700 font-bold text-lg">Training Compliance</p>
                <p className="text-6xl font-black text-amber-900 mt-2">88%</p>
                <p className="text-amber-700 font-semibold">Target: 95%</p>
              </div>
              <div className="bg-gradient-to-br from-yellow-100 to-orange-200 rounded-2xl p-8 border-3 border-yellow-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-yellow-700 font-bold text-lg">Active Programs</p>
                <p className="text-6xl font-black text-yellow-900 mt-2">20</p>
                <p className="text-yellow-700 font-semibold">Courses</p>
              </div>
              <div className="bg-gradient-to-br from-orange-100 to-red-200 rounded-2xl p-8 border-3 border-orange-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-orange-700 font-bold text-lg">Completion Rate</p>
                <p className="text-6xl font-black text-orange-900 mt-2">82%</p>
                <p className="text-orange-700 font-semibold">Avg</p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-amber-100 to-yellow-200 rounded-2xl p-8 border-3 border-amber-400 shadow-lg">
              <h2 className="text-4xl font-black text-amber-900 mb-6">Learning & Development Portfolio</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <p className="text-4xl font-black text-amber-700">450</p>
                  <p className="text-amber-800 font-bold mt-2">Trained Employees</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-yellow-700">1,200</p>
                  <p className="text-yellow-800 font-bold mt-2">Training Hours</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-orange-700">6</p>
                  <p className="text-orange-800 font-bold mt-2">Leadership Programs</p>
                </div>
                <div>
                  <p className="text-4xl font-black text-red-700">₱125K</p>
                  <p className="text-red-800 font-bold mt-2">Avg Investment</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* STRATEGIC HR */}
        {activeTab === 5 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-violet-100 to-purple-200 rounded-2xl p-8 border-3 border-violet-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-violet-700 font-bold text-lg">Succession Coverage</p>
                <p className="text-6xl font-black text-violet-900 mt-2">85%</p>
                <p className="text-violet-700 font-semibold">Critical Roles</p>
              </div>
              <div className="bg-gradient-to-br from-purple-100 to-pink-200 rounded-2xl p-8 border-3 border-purple-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-purple-700 font-bold text-lg">High Potentials</p>
                <p className="text-6xl font-black text-purple-900 mt-2">15</p>
                <p className="text-purple-700 font-semibold">In Pipeline</p>
              </div>
              <div className="bg-gradient-to-br from-indigo-100 to-blue-200 rounded-2xl p-8 border-3 border-indigo-400 shadow-lg text-center hover:shadow-xl transition">
                <p className="text-indigo-700 font-bold text-lg">Org Capability</p>
                <p className="text-6xl font-black text-indigo-900 mt-2">92%</p>
                <p className="text-indigo-700 font-semibold">Maturity</p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-violet-100 to-purple-200 rounded-2xl p-8 border-3 border-violet-400 shadow-lg">
              <h2 className="text-4xl font-black text-violet-900 mb-6">Strategic HR Initiatives</h2>
              <div className="space-y-4">
                <div className="bg-white/50 rounded-lg p-4">
                  <p className="text-violet-900 font-black text-lg">✓ Organizational Redesign</p>
                  <p className="text-violet-700 font-semibold">Q3-Q4 2026 rollout</p>
                </div>
                <div className="bg-white/50 rounded-lg p-4">
                  <p className="text-purple-900 font-black text-lg">✓ Talent Management Framework</p>
                  <p className="text-purple-700 font-semibold">Competency alignment in progress</p>
                </div>
                <div className="bg-white/50 rounded-lg p-4">
                  <p className="text-indigo-900 font-black text-lg">✓ Culture Transformation</p>
                  <p className="text-indigo-700 font-semibold">Engagement surveys - 78% positive</p>
                </div>
                <div className="bg-white/50 rounded-lg p-4">
                  <p className="text-pink-900 font-black text-lg">✓ Digital HR Roadmap</p>
                  <p className="text-pink-700 font-semibold">HRIS implementation planned</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* FOOTER */}
      <div className="max-w-7xl mx-auto mt-12 bg-gradient-to-r from-gray-900 to-gray-800 text-white text-center py-8 rounded-2xl shadow-lg">
        <p className="font-bold text-lg">CMG HRIS Dashboard | SBU: Construction & Manufacturing Group | PSC • ABC • CSI</p>
      </div>
    </div>
  );
}
